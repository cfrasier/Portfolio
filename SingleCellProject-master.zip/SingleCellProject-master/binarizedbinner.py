import csv

bin1 = []
bin2 = []
bin3 = []
bin4 = []
bin5 = []
bin6 = []
bin7 = []
bin8 = []
bin9 = []

bin1checkers = {'aay','Ama'}
bin2checkers = set(input("Please provide the genes to be checked for bin number 2: ").split(", "))
bin3checkers = {}
bin4checkers = {}
bin5checkers = {}
bin6checkers = {}
bin7checkers = {}
bin8checkers = {}
bin9checkers = {}

with open('self_binarized_bdtnp.csv') as csvfile:
	reader = csv.DictReader(csvfile)
	for row in reader:
		#print row
		total_on = 0
		genes_on = []
		dgenes_on = {}
		CellID = row['CellID']
		for item in row:
			if row[item] == '1':
				genes_on.append(item)
				total_on += 1
		#print(row['CellID'],total_on)
		#print(row['CellID'] +"\t"+str(genes_on)+"\t" + str(total_on))
		dgenes_on[CellID] = set(genes_on)
		#print(dgenes_on)
		if bin2checkers.issubset(dgenes_on[CellID]):
			bin2.append(CellID)
		#for item in dgenes_on[CellID]:
			#if item in bin1checkers:
				#bin1.append(CellID)

print(bin2)
